package lodz.uni.math;

public class A extends B{

	public A(){System.out.print("A1 "); }
	public void test() {
		System.out.print("T1 ");
		
	}
	//usuwamy static z test�w
	{
		System.out.print("I1 ");
	}
	static {
		System.out.print("G1 ");
	}
}

