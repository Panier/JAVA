package hamerski.project1.storage;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x,y,z,capacity;
		//System.out.print("Podaj x: ");
		capacity=4;
		x=3;
		y=3;
		z=4;
		Qube kostka=new Qube(x,y,z);
		kostka.fillQube(capacity);
	}
	

}
