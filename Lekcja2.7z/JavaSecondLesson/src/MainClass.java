
public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a = new Dog2();
		Dog2 b = new Dog2();
		a.eat();
		b.eat();
	}


}
