
public class Animal {
public void eat(){}
}
