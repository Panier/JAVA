package hamerski.project1.storage;

public class Qube {
	private
	int x,y,z;
	int[][] floor;
	
	public
	
		

	Qube(int _x,int _y, int _z){
		this.x=_x;
		this.y=_y;
		this.z=_z;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public int getZ(){
		return z;
	}
	
	public void createSlots(){ //stworzyc listy(stosy) dla kazdego pola w tablicy
		floor=new int[x][y];
		for (int i=0;i<x;i++)
		{
			for(int j=0;j<y;j++)
			{
				
			}
		}
		
	}

	public void fillQube(int capacity) { //tworzymy paczki z odpowiednimi numerami i priority
		int priority1=1,priority2=2,priority3=3;
		
		for (int i=0;i<capacity;i++)
		{
			if (capacity <= 3)
			new Package(i,priority1);
		}

	}
	
}
