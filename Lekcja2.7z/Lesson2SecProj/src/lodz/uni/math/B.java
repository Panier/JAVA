package lodz.uni.math;

public class B {
	public B()
	{
		System.out.print("MB1 ");
	}
	public void test() {
		System.out.print("MB2 ");
		
	}
	{
		System.out.print("MB3 ");
	}
	static {
		System.out.print("MB4 ");
	}
}
