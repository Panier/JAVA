
public class Dog2 extends Animal{
	public void eat(){}
}
