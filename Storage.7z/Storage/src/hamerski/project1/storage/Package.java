package hamerski.project1.storage;

public class Package {

	Package(int number,int priority)
	{
		
	}
}
