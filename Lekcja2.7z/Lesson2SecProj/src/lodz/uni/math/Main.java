package lodz.uni.math;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//A a=new A();
		//A.test();
		A b=new A();
		b.test();
	}

}
